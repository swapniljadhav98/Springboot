package com.example.demo.dto;



public class Book {

	public int StudId;
	public String name;
	public int price;
	public Book(int i, String string, int j)
	{
		StudId=i;
		name=string;
		price=j;
		// TODO Auto-generated constructor stub
	}
	

}