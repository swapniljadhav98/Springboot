package com.example.Daba.Daba;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan(basePackages= {com.example.Daba.Daba})
public class DabaApplication {

	public static void main(String[] args) {
		SpringApplication.run(DabaApplication.class, args);
	}

}
