package com.example.Daba.Daba;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DabaApplicationTests {

	@Test
	void contextLoads() {
	}

}
